SELECT  NOMBRE
FROM    CICLISTA
WHERE   (SELECT COUNT(*)
        FROM    PUERTO
        WHERE   PUERTO.DORSAL=CICLISTA.DORSAL)>1;
                       
                           