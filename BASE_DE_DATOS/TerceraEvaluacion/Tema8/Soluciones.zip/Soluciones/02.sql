              
--VERSION IN                   
SELECT  NETAPA, KM
FROM    ETAPA E
WHERE   NETAPA NOT IN (SELECT   NETAPA
                      FROM    PUERTO P);
					  
--VERSI�N EXISTS
SELECT  NETAPA, KM
FROM    ETAPA E
WHERE   NOT EXISTS (SELECT *
                   FROM    PUERTO P
                   WHERE   P.NETAPA=E.NETAPA);					  