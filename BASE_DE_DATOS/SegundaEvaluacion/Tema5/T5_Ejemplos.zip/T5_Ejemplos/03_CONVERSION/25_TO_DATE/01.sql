--TO_DATE(cad[, 'formato'])
--Formato por defecto NLS_DATE_FORMAT

SELECT  TO_DATE('010117')
FROM    DUAL;

SELECT  TO_DATE('370101')
FROM    DUAL;