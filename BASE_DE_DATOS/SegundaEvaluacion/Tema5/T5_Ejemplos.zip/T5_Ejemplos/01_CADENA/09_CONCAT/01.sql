--CONCAT(cad1, cad2)

SELECT  CONCAT('El cliente se llama: ', nombre)
FROM    CLIENTE;