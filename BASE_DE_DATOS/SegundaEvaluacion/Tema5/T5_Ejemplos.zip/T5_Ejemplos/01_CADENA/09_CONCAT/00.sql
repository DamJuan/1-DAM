--CONCAT(cad1, cad2)

SELECT  CONCAT('Bases ', 'de datos')
FROM    DUAL;