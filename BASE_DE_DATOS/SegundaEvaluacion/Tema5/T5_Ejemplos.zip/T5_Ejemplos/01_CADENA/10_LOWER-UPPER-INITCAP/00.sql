--LOWER(cad), UPPER(cad), INITCAP(cad)

SELECT  LOWER('baSes DE datos'),UPPER('baSes DE datos'), INITCAP('baSes DE datos')
FROM    DUAL;