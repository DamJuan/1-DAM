--INSTR (cad1, cad2, [pos_inicio[, ocurrencia]])
--pos_inicio>0

SELECT  DESCRIP, INSTR (DESCRIP, ' ')
FROM    ARTICULO;