--REPLACE (cad, cad_busqueda, [cad_sustitucion])

SELECT  REPLACE ('BASES DE DATOS 1� DAM', 'DAM', 'ASIR')
FROM    DUAL;