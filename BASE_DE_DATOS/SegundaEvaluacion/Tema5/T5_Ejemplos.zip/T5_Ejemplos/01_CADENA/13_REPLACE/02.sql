--REPLACE (cad, cad_busqueda, [cad_sustitucion])

SELECT  REPLACE ('LA CHICA DEL TREN', 'A', 'OS')
FROM    DUAL;