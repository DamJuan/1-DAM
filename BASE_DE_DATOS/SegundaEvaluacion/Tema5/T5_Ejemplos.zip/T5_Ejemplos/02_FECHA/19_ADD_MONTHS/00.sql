--ADD_MONTHS(fecha, n)

SELECT  ADD_MONTHS(sysdate, 3)
FROM    DUAL;