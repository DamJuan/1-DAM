--LAST_DAY(fecha)
SELECT  LAST_DAY(sysdate)
FROM    DUAL;