--NEXT_DAY(fecha, cad)

SELECT  NEXT_DAY(sysdate, 'Viernes')
FROM    DUAL;