
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculadoraTest {

    @Test
    public void testSumar() {
        double resultado = Calculadora.sumar(5, 3);
        assertEquals(8, resultado, 0.001);
    }

    @Test
    public void testRestar() {
        double resultado = Calculadora.restar(5, 3);
        assertEquals(2, resultado, 0.001);
    }

    @Test
    public void testMultiplicar() {
        double resultado = Calculadora.multiplicar(5, 3);
        assertEquals(15, resultado, 0.001);
    }

    @Test
    public void testDividir() {
        double resultado = Calculadora.dividir(6, 3);
        assertEquals(2, resultado, 0.001);
    }

    //@Test(expected = ArithmeticException.class)
    //public void testDividirPorCero() {
    //    Calculadora.dividir(5, 0);
    //}
}
