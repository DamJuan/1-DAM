package app.utilidades;

import app.objetos.Batalla;
import app.objetos.ObjetoMagico;
import app.objetos.Personaje;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.*;

public class EntradaSalida {

    private static final Logger LOGGER = LogManager.getRootLogger();
    //TODO Adaptar la ruta de los ficheros
    public static final String RUTA_BBDD = "bbdd";
    public static final String RUTA_DATOS = "datos";
    public static final String DATA_FILE = "app.TemploOlvidado.dat";

    /**
     * Carga un fichero CSV con los personajes y los convierte en un mapa de personajes, donde la clave es el nombre
     * en uppercase y el valor es el personaje
     * @param nombreFichero nombre del fichero CSV
     * @return un mapa de personajes
     */
    public static Map<String, Personaje> cargarCSVPersonas(String nombreFichero) {

        //TODO completar
        return grupo;
    }

    /**
     * Carga un fichero CSV con los objetos mágicos y los convierte en un mapa de objetos mágicos
     * @param nombreFichero nombre del fichero CSV
     * @return un mapa de objetos mágicos
     */
    public static Map<Integer,ObjetoMagico> cargarCSVObjetos(String nombreFichero) {

        //TODO completar
        return grupo;
    }

    /**
     * Almacena una batalla en un fichero que puede contener otras batallas
     * @param batalla batalla a almacenar
     * @return true si se ha almacenado correctamente, false en caso contrario
     */
    public static boolean almacenarBatalla(Batalla batalla) {

        //TODO completar
    }


    /**
     * Recupera todas las batallas almacenadas en un fichero, son batallas que han sido épicas y han ganado los guardianes
     * @return una lista con todas las batallas almacenadas
     */
    public static List<Batalla> recuperarBatallas(){

        //TODO completar
    }

    public static boolean existePartidaGuardada() {
        //TODO completar
    }

}
