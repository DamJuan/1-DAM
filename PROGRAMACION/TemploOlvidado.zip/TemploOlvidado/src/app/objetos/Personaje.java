package app.objetos;

public class Personaje{

    //TODO completar manteniendo el nombre de las variables propuestas
    nombre;
    clase;
    atributo;
    penalizacion;
    puntosExperiencia;
    esGanador;

    /**
     * Obtiene los datos del personaje en el formato necesario para mostrarlos en pantalla de Versus
     * @return String con el nombre del personaje, su clase y su atributo
     */
    public String getDatosParaVS(){
        return this.nombre + ", " + this.clase + ", " + this.atributo + ", " + this.getValentia();
    }

}
