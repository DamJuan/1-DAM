package app;

import app.objetos.Batalla;
import app.objetos.ObjetoMagico;
import app.objetos.Personaje;
import app.utilidades.EntradaSalida;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

public class TemploOlvidado {

    private final String NOMBRE_ARCHIVO_PERSONAJES = "personajes.csv";
    private final String NOMBRE_ARCHIVO_OBJETOS = "objetos.csv";
    private final String NOMBRE_GUARDIANES = "guardianes";
    private final String NOMBRE_LADRONES = "ladrones";
    private final int NUM_OBJETOS_EQUIPADOS_PERMITIDOS = 3;
    private final int OPCION = 3;

    private Scanner sc = new Scanner(System.in);

    private Batalla batalla;

    public TemploOlvidado() {
        personajes = EntradaSalida.cargarCSVPersonas(NOMBRE_ARCHIVO_PERSONAJES);
        objetosMagicos = EntradaSalida.cargarCSVObjetos(NOMBRE_ARCHIVO_OBJETOS);
    }

    /**
     * Método que inicia el juego
     */
    public void jugar() {
        int opcion = seleccionarOpcionMenu();
        switch (opcion) {
            case 1:
                jugarPartida();
                break;
            case 2:
                mostrarBatallasEpicas();
                break;
            case 3:
                System.out.println("Gracias por elegirnos. Hasta la próxima.");
                break;
            default:
                System.out.println("Opción no válida. El programa se cerrará.");
        }
    }

    private void mostrarBatallasEpicas() {
        //TODO completar decidiendo el mejor tipo de colección para las batallas
        batallas = EntradaSalida.recuperarBatallas();
        if(batallas == null || batallas.isEmpty()) {
            System.out.println("No hay batallas épicas que mostrar.");
            return;
        }

        System.out.println("\n**BATALLAS ÉPICAS**");
        int contador = 1;
        for(Batalla batalla : batallas) {
            StringBuilder sb = new StringBuilder();
            sb.append("\nBATALLA ").append(contador);
            sb.append(batalla.isGanadaPorGuardianes()?" ganada por los guardianes:\n":" ganada por los ladrones:\n");
            System.out.println(sb);
            batalla.luchar();
            contador++;
            System.out.println("-------------------------------------------------");
        }
    }

    /**
     * Método que juega una partida de Templo Olvidado
     */
    private void jugarPartida() {

        batalla = nuevoJuego();
        batalla.luchar();
        if(batalla.isGanadaPorGuardianes()) {
            System.out.println("Los guardianes han ganado la batalla. Esta batalla ha sido épica. Quedará almacenada " +
                    " en la historia del templo.");
        } else {
            System.out.println("Los guardianes han perdido la batalla. Para aprender de ella, dejaremos registro" +
                    " en la historia del templo.");
        }

        if(!EntradaSalida.almacenarBatalla(batalla)) {
            System.out.println("Lo sentimos, ha ocurrido un error y no se ha podido almacenar la batalla.");
        }
    }

    private int seleccionarOpcionMenu() {
        System.out.println("\nBienvenido al **TEMPLO OLVIDADO**");
        System.out.println("1. Jugar");
        System.out.println("2. Ver batallas épicas");
        System.out.println("3. Salir");
        System.out.print("\nSeleccione una opción: ");
        return sc.nextInt();
    }

    /**
     * Método que inicia y solicita lo necesario para empezar una nueva partida
     * @return Batalla creada
     */
    private Batalla nuevoJuego() {
        int numeroPersonajes = seleccionNumeroPersonajes();
        //TODO completar
        return new Batalla(guardianes, ladrones);
    }

    private int seleccionNumeroPersonajes() {
        System.out.println("En primer lugar indica el número de guardianes que hay en el templo con un valor entre " +
                "1 y 5:");
        int num = 0;
        try {
            num = sc.nextInt();
            if(num <= 0 || num > 5) {
                do {
                    System.out.println("El número de guardianes debe ser un número entre 1 y 5. Vuelve a introducirlo:");
                    num = sc.nextInt();
                } while(num < 0 || num > 5);
            }
        } catch (InputMismatchException e) {
            LOGGER.error("El usuario ha introducido un valor no numérico.");
            System.out.println("El número de guardianes debía ser indicado mediante un número.");
        }
        return num;
    }

    /**
     * Método que crea a los personajes y los equipa con objetos mágicos solicitándole los datos al usuario. Cómo los
     * personajes pueden ser de dos tipos, es necesario que se le indique el tipo. También es necesario indicar el
     * número de personajes que se quieren crear.
     * @param tipoPersonaje
     * @param cantidad
     * @return  Coleccion de personajes creados y equipados
     */
    private  crearEquiparPersonajes(String tipoPersonaje, int cantidad) {
        //TODO completar decidiendo el mejor tipo de colección para los personajes
        // personajes = seleccionarPersonajes(tipoPersonaje, cantidad);

        if(personajes.isEmpty()) {
            return null;
        }
        if(equiparPersonajes(personajes, tipoPersonaje, cantidad)) {
            return personajes;
        }
        return null;
    }

    /**
     * Método que crea a los personajes. Como los personajes pueden ser de dos tipos, es necesario que se le indique
     * el tipo. También es necesario indicar el número de personajes que se quieren crear.
     * @param tipoPersonaje
     * @param cantidad
     * @return  Coleccion de personajes creados y equipados
     */
    private  seleccionarPersonajes(String tipoPersonaje, int cantidad) {
        //TODO completar decidiendo el mejor tipo de colección para los personajes
         personajesSeleccionados = ;

        //Construyo el mensaje de selección de personajes:
        StringBuilder sb = new StringBuilder();
        sb.append("Elije a ").append(construirMensajeNumero(cantidad, tipoPersonaje));
        sb.append(" de entre los siguientes personajes.");
        System.out.println(sb.toString());

        mostrarPersonajes();

        //Limpio el buffer
        sc.nextLine();

        for(int i = 1; i <= cantidad; i++) {
            System.out.println("Introduce el nombre completo del personaje " + (i) + ":");
            String nombre = sc.nextLine();
            Personaje personaje = null;

            //TODO completar en función de la colección elegida
            if(personajes.contains()){

            } else {
                System.out.println("El personaje no existe. Prueba de nuevo.");
                i--;
            }
        }
        return personajesSeleccionados;
    }

    /**
     * Método que equipa a los personajes con objetos mágicos. Como los personajes pueden ser de dos tipos, es
     * necesario que se le indique el tipo. También es necesario indicar el número de personajes que se quieren crear.
     * @param personajes es necesario pasarle la colección de personajes
     * @param tipoPersonaje
     * @param cantidad
     * @return true si se han equipado correctamente, false en caso contrario
     */
    private boolean equiparPersonajes( personajes, String tipoPersonaje, int cantidad) {
        //TODO completar con el mejor tipo de colección para los personajes

        //Construyo el mensaje de selección de personajes:
        StringBuilder sb = new StringBuilder();
        sb.append("Ahora debes equipar a ").append(construirMensajeNumero(cantidad, tipoPersonaje));
        sb.append(" con ").append(NUM_OBJETOS_EQUIPADOS_PERMITIDOS).append(" objetos mágicos");
        sb.append(cantidad > 1?" para cada uno.":".");
        System.out.println(sb);

        mostrarObjetosMagicos();

        for(Personaje personaje : personajes) {
            //TODO completar con el mejor tipo de colección para los objetos
             objetosMagicos = equipar(personaje);

            //TODO Completar
        }
        return Boolean.TRUE;
    }

    /**
     * Método que equipa a un personaje con los objetos mágicos seleccionados por el usuario. Se le solicita al
     * usuario que introduzca el identificador de los objetos mágicos que quiere equipar al personaje. Se equipará al
     * personaje con tanto objetos mágicos como se le indique en la constante NUM_OBJETOS_EQUIPADOS_PERMITIDOS.
     * @param personaje
     * @param  Coleccion de objetos
     */
    private  equipar(Personaje personaje) {
        //TODO crear la colección de objetos mágicos del mejor tipo posible
         objetosMagicos = ;

        //TODO completar
        return objetosMagicos;
    }

    private void mostrarPersonajes() {
        //TODO completar en función de la colección elegida
        // System.out.println(personajes);
    }

    private void mostrarObjetosMagicos() {
        //TODO completar en función de la colección elegida
        // System.out.println(objetosMagicos);

    }

    private String construirMensajeNumero(int cantidad, String tipoPersonaje) {
        StringBuilder sb = new StringBuilder();
        sb.append("tu").append(cantidad>1?"s " + cantidad + " ":" ");
        if(cantidad > 1){
            sb.append(tipoPersonaje.equals(NOMBRE_GUARDIANES)?"GUARDIANES":"LADRONES");
        } else {
            sb.append(tipoPersonaje.equals(NOMBRE_GUARDIANES)?"GUARDIÁN":"LADRÓN");
        }
        return sb.toString();
    }
}
