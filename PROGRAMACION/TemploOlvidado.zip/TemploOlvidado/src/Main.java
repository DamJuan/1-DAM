import app.TemploOlvidado;

public class Main {
    public static void main(String[] args) {
        TemploOlvidado templo = new TemploOlvidado();
        templo.jugar();
    }
}
