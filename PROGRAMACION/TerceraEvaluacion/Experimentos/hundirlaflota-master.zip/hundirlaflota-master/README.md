# Hundir la Flota
Este es el pequeño juego de hundir la flota realizado en JAVA
Se genera un tablero en la consola y hay que adivinar en que posición estan los barcos

Si quieremos decir una posición solo tenemos que decir la letra y luego el número por ejemplo:"B2"
El programa cuenta con la clase principal que es ``HundirlaFlota.java`` en la que controla todos los movimientos que vamos diciendo y controla el juego sobre el tablero.

La clase ``barco.java`` sirve para generar estos barcos al principo de la partida y almacenarlos en un ArrayList
Ya que esto solo es la prueba de funcionamiento se muestran los datos de los barcos con las posiciones que ocupan en el tablero en la que ``posicion={2,2 3,2}`` se refiere al que el barco ocupan las posiciones B2 y C2

![alt text](https://github.com/FerminOrtega/hundirlaflota/blob/master/README%20IMG.png?raw=true)
